//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"

#if __has_include(<camera_deep_ar/CameraDeepArPlugin.h>)
#import <camera_deep_ar/CameraDeepArPlugin.h>
#else
@import camera_deep_ar;
#endif

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [CameraDeepArPlugin registerWithRegistrar:[registry registrarForPlugin:@"CameraDeepArPlugin"]];
}

@end
